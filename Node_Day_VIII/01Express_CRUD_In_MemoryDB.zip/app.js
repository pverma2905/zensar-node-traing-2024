const express = require('express');

// Create an express app
const app = express();

// Setting the view engine - pug
app.set('view engine','pug');

const indexRouter = require('./routes/index');
const employeesRouter = require('./routes/employees');

// Built-in middleware to fulfill request object
// For the request body
app.use(express.urlencoded({extended:false}));

app.use('/',indexRouter);
app.use('/employees',employeesRouter);

app.use((err,req,res,next) =>{
    console.log(`${err.stack}`);
    res.status(500).send('Server Error! '+err);
})


module.exports = app;
