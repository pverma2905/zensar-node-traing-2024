
const express = require('express');
const router = express.Router();

const empCtrl = require('../controllers/employees-controller');

// getAll
router.get('/',empCtrl.index);

// details
router.get('/details/:empid',empCtrl.details)

//delete get
router.get('/delete/:empid',empCtrl.delete_get)
// delete post
router.post('/delete/:empid',empCtrl.delete_post)


//create get
router.get('/create',empCtrl.insert_get)
//create post
router.post('/create',empCtrl.insert_post)


//edit get
router.get('/edit/:empid',empCtrl.edit_get)
//edit post
router.post('/edit/:empid',empCtrl.edit_post)

module.exports = router;

// getById - Details
// Insert
// Update
