const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// middleware
app.use(express.json());// for body
app.use(express.urlencoded({extended:false})); // for urlencoded
app.use(cors()); // cross origin resource sharing


// MongoDB connection
mongoose.connect('mongodb://localhost:27017/ItemsDB',{})
.then(() =>{
    console.log('Connected to MongoDB!');
}).catch(err =>{
    console.error('Could not connect to MongoDB ',err);
});

// Define a schema and model for your data
const itemSchema = new mongoose.Schema({
    name:{type:String,required:true},
    price:{type:Number,required:true}
});

const Item = mongoose.model('Item',itemSchema);


// RESTful routes

// Get all items
app.get('/api/items',async(req,res) =>{
    try{
        
        const items = await Item.find();
        res.status(200).json(items);

    }catch(error){
        res.status(500).json({message: 'Error retrieving items'});
    }
})

// Get item by id
app.get('/api/items/:id',async(req,res) =>{
    try{
        const item = await Item.findById(req.params.id);
        if(!item) return res.status(404).json({message:'Item not found'});
        res.status(200).json(item);

    }catch(error){
        res.status(500).json({message: 'Error retrieving item'});
    }
})

// Start the server
app.listen(PORT,()=>{
    console.log(`Server running on port ${PORT}`);
})


// Create a New Item
app.post('/api/items',async (req,res)=>{
    const newItem = new Item(req.body);
    try{
        const savedItem = await newItem.save();
        res.status(201).json(savedItem);

    }catch(error){
        res.status(400).json({message: 'Error creating item'});
    }
})


// Update an Existing Item
app.put('/api/items/:id',async (req,res)=>{
    try{
        const updatedItem = await Item.findByIdAndUpdate(req.params.id,req.body,{new:true}); // {new:true} - ensures that you get the
                            // modified document after the update operation in return;
        if(!updatedItem) return res.status(404).json({message:'Item not found'});
        res.status(200).json(updatedItem);

    }catch(error){
        res.status(400).json({message: 'Error updating item'});
    }
})


// Delete an Existing Item
app.delete('/api/items/:id',async (req,res)=>{
    try{
        const deletedItem = await Item.findByIdAndDelete(req.params.id);
        if(!deletedItem) return res.status(404).json({message:'Item not found'});
        res.status(200).json({message:' Item deleted'});

    }catch(error){
        res.status(500).json({message: 'Error deleting item'});
    }
})