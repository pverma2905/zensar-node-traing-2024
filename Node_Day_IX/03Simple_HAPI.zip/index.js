
const Hapi = require('@hapi/hapi');


const init = async () =>{

    const server = Hapi.server({
        port:3000,
        host:'localhost'
    });

    // routes
    server.route({
        method:'GET', // any valid HTTP method or an array of HTTP methods or *
        path:'/', // path defines path even include parameters.
        // handler must return a value, a promise, or throw an error.
        // h is the resource toolkit, which is an object with serveral
        // methods use to response to the request.
        handler:(request,h) =>{ 
            return "<h1>Hello World!</h1>";
        }
    })

    // passing parameters
    server.route({
        method:'GET',
        path:'/greet/{name}',
        handler:(request,h) =>{ 
            const name = request.params.name;
            return "<h1>Welcome "+name+ "!</h1>";
        }
    })

    // h - response toolkit
    server.route({
        method:'GET',
        path:'/home',
        handler:(request,h) =>{ 
            // return h.redirect('/');
            return h.redirect('/greet/Abhijeet');
            //return "<h1>Welcome Home!</h1>";
        }
    })

    // response - some data
    server.route({
        method:'GET',
        path:'/user',
        handler:(request,h) =>{ 
            const user = {
                firstName:'Sachin',
                lastName:'Tendulkar',
                userName:'MasterBlaster',
                id:10
            }
            return user;
        }
    })

    await server.start();
    console.log('Server running on %s',server.info.uri);
}

process.on('unhandledRejection',(err)=>{
    console.error(err);
    process.exit(1);
})

init();