const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const path = require('path');
const userRoutes = require('./routes/userRoutes');

dotenv.config();

const app = express();

// Mongodb Connection
mongoose.connect(process.env.MONGODB_URI,{})
.then(() => console.log('MongoDB Connected!....'))
.catch((err) => console.error('MongoDB connection error ',err));

// for body to fulfill the data
app.use(express.json());
app.use(express.urlencoded({extended:false}));

// Set pug as a view engine
app.set('view engine','pug');
app.set('views',path.join(__dirname,'views'));

// Routes
app.use('/',userRoutes);

// Start the server
const PORT = process.env.PORT || 3000;

app.listen(PORT,() =>{
    console.log(`Server running on port ${PORT}`);
})