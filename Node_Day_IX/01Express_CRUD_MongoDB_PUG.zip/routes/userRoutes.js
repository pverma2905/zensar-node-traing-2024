
const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');

router.get('/',userController.getUsers);

router.get('/user/details/:id',userController.getUser);

router.get('/user/add',userController.addUserForm);
router.post('/user/add',userController.addUser);

router.get('/user/edit/:id',userController.editUserForm);
router.post('/user/edit/:id',userController.editUser);

router.post('/user/delete/:id',userController.deleteUser);


module.exports = router;