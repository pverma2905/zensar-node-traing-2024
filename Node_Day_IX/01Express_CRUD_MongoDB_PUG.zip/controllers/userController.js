
const User = require('../models/user');

exports.getUsers = async (req,res)=>{
    try{
        const users = await User.find();
        res.render('index', {users});
    }catch(err){
        res.status(500).send('Server Error');
    }
}

//get or details
exports.getUser = async (req,res)=>{
    try{
        const user = await User.findById(req.params.id);
        res.render('details', {user});
    }catch(err){
        res.status(500).send('Server Error');
    }
}

//add get
exports.addUserForm = (req,res) =>{
    res.render('add');
}


//add post
exports.addUser = async (req,res) =>{
    const {name,email,age} = req.body;
    try{
        await User.create({name,email,age});
        res.redirect('/');
    }catch(err){
        res.status(500).send('Server Error');
    }
}

//edit get
exports.editUserForm =  async (req,res) =>{
    try{
        const user = await User.findById(req.params.id);
        res.render('edit',{user});
    }catch(err){
        res.status(500).send('Server Error');
    }
}


//edit post
exports.editUser = async (req,res) =>{
    const {name,email,age} = req.body;
    try{
        await User.findByIdAndUpdate(req.params.id,{name,email,age});
        res.redirect('/');
    }catch(err){
        res.status(500).send('Server Error');
    }
}

//delete 
exports.deleteUser = async (req,res) =>{
    try{
        await User.findByIdAndDelete(req.params.id)
        res.redirect('/');
    }catch(err){
        res.status(500).send('Server Error');
    }
}



// Assignment edit User
