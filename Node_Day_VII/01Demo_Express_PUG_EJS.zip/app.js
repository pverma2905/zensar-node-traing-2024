// const express = require('express');
// let app = express();
// const http = require('http');

// app.set('view engine','pug');

// // app.get('/',function(req,res){
// //     res.send('<h1>Hello World using ExpressJS!</h1>');
// // })

// app.get('/',function(req,res){
//     res.render('pug/home');
// })

// // model
// let employees = [
//     {id:1,name:'Sachin'},
//     {id:2,name:'Rahul'},
//     {id:3,name:'Sourav'}
// ]

// // controller
// app.get('/employees',function(req,res){
//     // pushing model's data to the view
//     res.render('pug/employees',{pageTitle:'Employees View!',empList:employees});
// })

// const server = http.createServer(app);

// server.listen(9876);

// function onError(err){
//     console.error(err);
// }

// function onListening(){
//     var address =server.address();
//     console.log('Server started on port: '+address.port);
// }

// server.on('error',onError);
// server.on('listening',onListening);


// Dealing with EJS - Embedded Javascript Template

const express = require('express');
let app = express();
const http = require('http');

app.set('view engine','ejs');

app.get('/',function(req,res){
    res.render('ejs/home',{myHeader:'My Page Header!'});
})

// For static resource
// http://localhost:9876/images/bruce.jpg
app.use(express.static('public'));

// model
const recipes = [
    { "Id": "1", "name": "Tawa Surmai", "url": "https://food.ndtv.com/recipe-tawa-surmai-707370" },
    { "Id": "2", "name": "Prawn Balchao with Appams", "url": "http://food.ndtv.com/recipe-prawn-balchao-with-appams-218053" },
    { "Id": "3", "name": "Mediterranean Watermelon Salad", "url": "http://food.ndtv.com/recipe-mediterranean-watermelon-salad-507291" },
    { "Id": "4", "name": "Chicken Xacuti", "url": "http://food.ndtv.com/recipe-chicken-xacuti-287147" },
    { "Id": "5", "name": "Pasta with Tangy Tomato Sauce", "url": "https://food.ndtv.com/recipe-pasta-with-tangy-tomato-sauce-952142" },
];

// controller
app.get('/recipes',function(req,res){
    // pushing model's data to the view
    res.render('ejs/recipes',{
        pageTitle:"Zensar's Kitchens - Recipes",
        recipes:recipes});
})

app.get('/recipes/:Id',function(req,res){
    var rs;
    for(var i in recipes){
        if(recipes[i].Id === req.params.Id){
            rs = recipes[i];
            break;
        }
    }
    res.render('ejs/recipe',{
        pageTitle:"Favorite Recipe",
        recipe:rs});
})

// Error Handling Middleware
app.use(function(req,res,next){
    var err = new Error('View Not Found!....');
    err.status = 404;

    next(err);
})

// Error Handling Middleware
app.use(function(err,req,res,next){
    res.status(err.status || 500);
    if(!err.status){
        err.status = 500;
    }
    res.render('ejs/error',{
        message:err.message,
        status:err.status
    })
})

const server = http.createServer(app);

server.listen(9876);

function onError(err){
    console.error(err);
}

function onListening(){
    var address =server.address();
    console.log('Server started on port: '+address.port);
}

server.on('error',onError);
server.on('listening',onListening);