
let employees = [
    {id:1,name:'Ashish'},
    {id:2,name:'Manish'},
    {id:3,name:'Amar'},
    {id:4,name:'Aditya'},
    {id:5,name:'Rahul'}
]

exports.getAllEmployees = function(){
    return employees;
}

exports.getEmployee = function(id){
    return employees.find(e => e.id === Number(id));
}

exports.deleteEmployee = function(id){
    employees = [...employees.filter(e => e.id !== parseInt(id))];
    return true;
}