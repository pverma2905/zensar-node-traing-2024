exports.index = (req,res) =>{
    res.render('home/index',{pageTitle:'Index View!'})
}