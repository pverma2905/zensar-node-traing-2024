
const express = require('express');
const router = express.Router();

const da = require('../data-access');

// getAll
router.get('/',(req,res) =>{
    res.render('employees',{
        pageTitle:'Employees View!',
        empList:da.getAllEmployees()
    });
})

//delete get
router.get('/delete/:empid',(req,res) =>{
    var id = req.params.empid;
    res.render("delete",{
        pageTitle:'Employee Delete View!',
        employee: da.getEmployee(id)
    })
})
// delete post
router.post('/delete/:empid',(req,res) =>{
    var id = req.params.empid;
   if(da.deleteEmployee(id)){
        res.redirect('/employees');
   }else{
        res.render('employees/delete',{
            pageTitle:'Employee Delete View!',
            employee: da.getEmployee(id)  
        })
   }
})

module.exports = router;

// getById - Details
// Insert
// Update
