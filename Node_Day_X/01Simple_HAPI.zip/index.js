
const Hapi = require('@hapi/hapi');


const init = async () =>{

    const server = Hapi.server({
        port:3000,
        host:'localhost'
    });

    // routes
    server.route({
        method:'GET', // any valid HTTP method or an array of HTTP methods or *
        path:'/', // path defines path even include parameters.
        // handler must return a value, a promise, or throw an error.
        // h is the resource toolkit, which is an object with serveral
        // methods use to response to the request.
        handler:(request,h) =>{ 
            return "<h1>Hello World!</h1>";
        }
    })

    // passing parameters
    server.route({
        method:'GET',
        path:'/greet/{name}',
        handler:(request,h) =>{ 
            const name = request.params.name;
            return "<h1>Welcome "+name+ "!</h1>";
        }
    })

    // h - response toolkit
    server.route({
        method:'GET',
        path:'/home',
        handler:(request,h) =>{ 
            // return h.redirect('/');
            return h.redirect('/greet/Abhijeet');
            //return "<h1>Welcome Home!</h1>";
        }
    })

    // response - some data
    server.route({
        method:'GET',
        path:'/user',
        handler:(request,h) =>{ 
            const user = {
                firstName:'Sachin',
                lastName:'Tendulkar',
                userName:'MasterBlaster',
                id:10
            }
            return user;
        }
    })

    /*
    plugin - In Hapi.js a plugin is a way to encapsulate and organize your
    applications' functionality into reusable components.
    Plugins allow you to break your application into isolated pieces of
    business logic and utilities, making your code more modular
    and maintainable.
    */
    
    // Custom plugin - getDate
    const getDate = {
        name:'getDate',
        version:'1.0.0',
        register: async function(server, options){

            const currentDate = function(){
                const date = new Date().toDateString();
                return date + ' from '+options.name;
            }

            server.decorate('toolkit','getDate',currentDate);
        }
    }

    // Another Custom plugin - getTime
    const getTime = {
        name:'getTime',
        version:'1.0.0',
        register: async function(server, options){

            const currentTime = function(){
                const time = new Date().toTimeString();
                return time + ' from '+options.name;
            }

            server.decorate('toolkit','getTime',currentTime);
        }
    }

    // Call server.register to load the plugin
    await server.register([
        {
            plugin:getDate,
            options:{
                name:'Ashish'
            }
        },
        {
            plugin:getTime,
            options:{
                name:'Rahul'
            }
        }
    ])

    // Testing plugin in the route
    server.route({
        method:'GET',
        path:'/test',
        handler:(request,h) => { 
            return '<h1> Test route with plugins - getDate & getTime! </h1>'
                    + h.getDate() +'<br/>'
                    + h.getTime();
        }
    })


    /*
    In Hapi.js an extension refers to a way to hook into the request lifecycle
    at various points to execute custom logic.
    Hapi provides seven extension points

    onRequest - called at the very begining of the request lifecycle.
    onPreAuth - called at the authentication process.
    onCredentials - called after the authentication process but before
    the authorization process.
    onPostAuth -called after the authorization process.
    onPreHandler - called before the request handler is executed.
    onPostHandler - called after the request handler has completed.
    onPreResponse - called before the response is sent back to the client.

    To add a function to an extension point, you use server.ext() method.
     */

    // extension method
    // server.ext('onRequest',function(request,h){
    //     request.setUrl('/user');
    //     return h.continue;
    // })

    server.ext('onPreResponse',function(request,h){
       
        const response = request.response;

        // Check if the response is an error
        if(response.isBoom){
            // customize the error response
            return h.response({
                statusCode: response.output.statusCode,
                error:response.output.payload.error,
                message:'Url:- '+request.url+' Something went wrong!'
            }).code(response.output.statusCode);
        }

        return h.continue;
    });


    await server.start();
    console.log('Server running on %s',server.info.uri);
}

/*
In Hapi.js unhandledRejection is an event that is triggered
when a promise is rejected and the rejection is not hanlded by any
.catch() method or try/catch block.
This is Node.js event, not specific to hapi, but it's commonly used in
Hapi applications to catch and hanle unexpected errors that might otherwise
crash the server.

This is good practise to ensure that your application doens't silently fail
and that you are aware of any unhandled errors that need to be addressed.
 */

process.on('unhandledRejection',(err)=>{
    console.error(err);
    process.exit(1);
})

init();