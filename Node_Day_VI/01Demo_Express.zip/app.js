
const http = require('http');
const express = require('express');

// Create an Express Application
const app = express();

// app.get('/', function (req, res) {
//     res.send('Hello World');
// });

app.get('/', function (req, res) {
    res.sendFile(__dirname+"/public/index.html");
});

app.get('/contact', function (req, res) {
    res.sendFile(__dirname+"/public/contact.html");
});

app.get('/about', function (req, res) {
    res.sendFile(__dirname+"/public/about.html");
});

const employees = [
    {id:1,name:'Ashish'},
    {id:2,name:'Manish'},
    {id:3,name:'Raj'},
    {id:4,name:'Amar'},
    {id:5,name:'Aditya'},
    {id:6,name:'Saket'},
]

app.get('/data', function (req, res) {
    const data = employees;
    res.json(data);
});

const server = http.createServer(app);

server.listen(3300);

function onError(err){
    console.error(err);
}

function onListening(){
    var address =server.address();
    console.log('Server started on port: '+address.port);
}

server.on('error',onError);
server.on('listening',onListening);