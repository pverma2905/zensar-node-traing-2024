
const http = require('http');
const express = require('express');

// Create an Express Application
const app = express();

// Setting the view engine to pug
app.set('view engine','pug');

app.get('/', function (req, res) {
    // controller's code to render the view with model's data.
    res.render('index',{pageTitle:'Index View'})
});

const employees = [
    {id:1,name:'Ashish'},
    {id:2,name:'Manish'},
    {id:3,name:'Raj'},
    {id:4,name:'Amar'},
    {id:5,name:'Aditya'},
    {id:6,name:'Saket'},
]


app.get('/employees', function (req, res) {
    // controller's code to render the view with model's data.
    res.render('employees',{
        pageTitle:'Employees View',
        empList:employees
    })
});


const server = http.createServer(app);

server.listen(3300);

function onError(err){
    console.error(err);
}

function onListening(){
    var address =server.address();
    console.log('Server started on port: '+address.port);
}

server.on('error',onError);
server.on('listening',onListening);